java{curl
>> 'start
>> java'
>> curl{execute
>> stop
>> {
>> java{curl
>> '
>> run
>>